import queue
import threading
import time, requests, sys
from models.ScanResult import ScanResult
from models.ScanResultType import ScanResultType

# python3 check.py {commend_suffix.txt} {input file}

directory_list = []

q = queue.Queue()
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
}

# Worker, handles each task
def worker():
    while True:
        item = q.get()
        if item is None:
            break
        try:
            r = requests.get(item, verify=False, timeout=10, headers=headers)
            result = True if r.status_code == 200 else False
            output = item + " | " + str(r.status_code) + " | " + str(result)
            print(output)
            if result:
                directory_list.append(output)

        except Exception as e:
            output = item + " | " + "Timeout / Exception" + " | " + str(False)
            print(output)
            directory_list.append(output)
            # print(e.with_traceback())

        time.sleep(1)
        q.task_done()


def start_workers(worker_pool=1000):
    threads = []
    for i in range(worker_pool):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)
    return threads


def stop_workers(threads):
    # stop workers
    for i in threads:
        q.put(None)
    for t in threads:
        t.join()


def create_queue(task_items):
    for item in task_items:
        q.put(item)


def pen(ip, port):
    tasks = []

    # parse suffix
    suffixes = []
    with open("cve_scan/http_directory_list_common.txt", "r") as f:
        for l in f:
            l = l.replace("\n", "")
            suffixes.append(l)

    # parse input file
    inputs = []
    url = "http://" + (ip[:-1] if ip[-1] == "/" else ip) + ((":" + str(port)) if port else "")
    inputs.append(url)
    url2 = "https://" + (ip[:-1] if ip[-1] == "/" else ip) + ((":" + str(port)) if port else "")
    inputs.append(url2)

    for suffix in suffixes:
        for input in inputs:
            tasks.append(input + "/" + suffix)

    # Start up your workers
    print("URL | STATUS_CODE | RESULT IS 200")
    workers = start_workers(worker_pool=10)
    create_queue(tasks)

    # Blocks until all tasks are complete
    q.join()
    stop_workers(workers)

    dirlist = directory_list.copy()
    directory_list.clear()
    dirlist_str = "\n".join(dirlist)
    if dirlist:
        return ScanResult(ScanResultType.vulnerable.value, dirlist_str)
    else:
        return ScanResult(ScanResultType.not_vulnerable.value)


if __name__ == "__main__":
    tasks = []

    # parse suffix
    suffixes = []
    with open(sys.argv[1], "r") as f:
        for l in f:
            l = l.replace("\n", "")
            suffixes.append(l)

    # parse input file
    inputs = []
    with open(sys.argv[2], "r") as f:
        for l in f:
            l = l.replace("\n", "")
            l = l[:-1] if l[-1] == "/" else l
            inputs.append(l)

    for suffix in suffixes:
        for input in inputs:
            tasks.append(input + "/" + suffix)

    # Start up your workers
    print("URL | STATUS_CODE | RESULT IS 200")
    workers = start_workers(worker_pool=10)
    create_queue(tasks)

    # Blocks until all tasks are complete
    q.join()

    print("\n".join(directory_list))

    stop_workers(workers)
